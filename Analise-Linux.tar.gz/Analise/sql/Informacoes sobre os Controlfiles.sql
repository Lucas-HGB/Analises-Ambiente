Col name for a70
select * from v$controlfile;
