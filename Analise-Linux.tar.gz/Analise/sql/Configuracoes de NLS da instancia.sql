Col value$ for a60
Set pages 2000
SELECT name,value$ FROM sys.props$;
